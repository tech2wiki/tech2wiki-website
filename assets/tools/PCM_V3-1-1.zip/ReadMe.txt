PC Card Manager V3.1.1
(C) CSM GmbH, Filderstadt



CONTENTS_______________________________________________________________________

	OVERVIEW
	REQUIREMENTS
	PCM SHIPPING CONTENTS
	TRADEMARKS
	REVISION HISTORY



OVERVIEW_______________________________________________________________________

The PC Card Manager (PCM) is a utility to

    - Copy files to PC Cards
    - Copy PC Card contents to files
    - Compare PC Card with file(s)
    - Compute checksum over PC Card (regions)
    - Linear FLASH: Erase Card / Blank Check
    - Perform a surface scan on ATA cards
    - Format SRAM- or ATA PC Cards with FAT file system
    - Socket Status
    - Analyze PC Card (detect type/size)
    - Edit PC Cards (hex-editor)

PCM is completely format independed. PC Cards are treated as a binary
array of bytes.

PCM handles SRAM, Linear FLASH and ATA (FLASH and hard disks).
PC Card type and size are detected automatically whenever possible.



REQUIREMENTS___________________________________________________________________

Operating-System
	PCM has been tested on the operating systems:
    	- Win7 / Win8 / Win10
	PCM will not work with non-Microsoft or 16-bit operating systems.

Drivers
    A CSM PC Card driver supporting the IoCtl32 API is required. At this time,
    the following product is in several versions available:
        - OmniDrive USB2 Professional

As of V3.0, PCM can operate on physical drives, even if there is no CSM
PC Card driver available. See PCM help for more information about this 
feature.
        


PCM SHIPPING CONTENTS__________________________________________________________

PCM ships as a single setup file SETUP.EXE.
The setup contains the PCM executable and the windows HTML-help file.



TRADEMARKS_____________________________________________________________________

'Microsoft' and 'Windows' are registered trademarks of Microsoft
Corporation. All other trademarks mentioned in the documentation are
properties of their respective owners.



REVISION HISTORY_______________________________________________________________

V3.1.1  06/2015 Update aladdin (Safenet) dongle driver to haspdinst 
		7.32.52580.1 for Windows 10
V3.1.0  10/2014 Analyze dialog allows ID of write protected ATA
V3.0.5  06/2013 Fixed FAT32 formatting problem for large media (>32GB)
V3.0.4  11/2011 Update aladdin (Safenet) dongle driver to haspdinst 6.21.22090.1
V3.0.3  12/2009 FAT32 formatting was broken
V3.0.2  07/2009 Updated aladdin dongle driver to fix an installation issue.
V3.0.1  05/2009 Volume locking and size limit for physical drives
V3.0.0  ---     Access to physical drives (requires SoftDrive Pro - dongle)
V2.13   10/2008 Fixed a bug with <512 byte transfers
V2.12   11/2007 Fixed a problem in EEPROM type detection
V2.11   07/2007 2GB clipping for old drives (Omni97/SD2000)
V2.10   05/2007 Additional checksum algorithms
V2.01   09/2006 FAT32/large address support. Handling improved
V1.61   02/2006 Support for new FLASH chips
V1.60   06/2005 Fixed a bug in SRAM size detection. Drag&Drop for file names
V1.51   02/2005 License
V1.50   01/2005 Minor fixes. Formatting facility updated.
V1.30   07/2003 SD/MMC analysis for OmniUSB SD-variants. Formatter improved. HTML-Help
V1.21   05/2001 Fixed a bug in FLASH erase (erasing single blocks)
V1.20   04/2001 ATA-Utilities
V1.10   02/2000 Formatting facility
V1.01   10/1999 Initial public release

NOTE:   The version number refers to the PCM setup package. It is not necessarily
        equal to the version of PCM.EXE.


_______________________________________________________________________________
This document is subject to change without notice.
(C) CSM Computer-Systeme-Messtechnik GmbH, Filderstadt, Germany
